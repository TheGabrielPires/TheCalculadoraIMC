package com.example.calculadoraimc;

import android.os.Bundle;
import android.widget.Button;
import android.content.Intent;


import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btn = findViewById(R.id.btn_calculadora);
        btn.setOnClickListener(v -> {
            Intent intent = new Intent(this, CalculoIMCActivity.class);
            startActivity(intent);
        });
    }
}
