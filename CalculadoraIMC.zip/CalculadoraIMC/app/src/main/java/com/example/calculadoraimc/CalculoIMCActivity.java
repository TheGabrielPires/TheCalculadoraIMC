package com.example.calculadoraimc;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class CalculoIMCActivity extends AppCompatActivity {
    EditText editPeso, editAltura;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculo_imc);

        editPeso = findViewById(R.id.editPeso);
        editAltura = findViewById(R.id.editAltura);

        findViewById(R.id.btn_calcular).setOnClickListener(v -> calcularIMC());
        findViewById(R.id.btn_limpar).setOnClickListener(v -> {
            editPeso.setText("");
            editAltura.setText("");
        });
        findViewById(R.id.btn_fechar).setOnClickListener(v -> finish());
    }

    void calcularIMC() {
        double peso = Double.parseDouble(editPeso.getText().toString());
        double altura = Double.parseDouble(editAltura.getText().toString());
        double imc = peso / (altura * altura);

        Intent intent;
        if (imc < 18.5) {
            intent = new Intent(this, AbaixoDoPesoActivity.class);
        } else if (imc < 25) {
            intent = new Intent(this, PesoNormalActivity.class);
        } else if (imc < 30) {
            intent = new Intent(this, SobrepesoActivity.class);
        } else if (imc < 35) {
            intent = new Intent(this, Obesidade1Activity.class);
        } else if (imc < 40) {
            intent = new Intent(this, Obesidade2Activity.class);
        } else {
            intent = new Intent(this, Obesidade3Activity.class);
        }

        intent.putExtra("peso", peso);
        intent.putExtra("altura", altura);
        intent.putExtra("imc", imc);
        startActivity(intent);
    }
}